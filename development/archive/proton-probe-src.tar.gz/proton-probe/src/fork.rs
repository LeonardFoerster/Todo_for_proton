//! Login per Browser-Session-Fork (wie das offizielle Drive-CLI für Drittanbieter-Forks).
//! Die App sieht weder Passwort noch 2FA; sie erhält Session-Tokens und das `keyPassword`.

use std::{
    process::{Command, Stdio},
    thread::sleep,
    time::{Duration, Instant},
};

use aes_gcm::{
    aead::{Aead, KeyInit, Payload},
    Aes256Gcm,
};
use base64::{engine::general_purpose::STANDARD, Engine};
use serde_json::Value;

use crate::api::{Api, Session};

const ACCOUNT_URL: &str = "https://account.proton.me";
const AUTH_CLIENT_ID: &str = "external-drive";
const POLL_INTERVAL: Duration = Duration::from_secs(5);
const MAX_POLL: Duration = Duration::from_secs(10 * 60);

/// Entschlüsseltes Schlüssel-Passwort. Ohne `Debug`.
pub struct KeyPassword(#[allow(dead_code)] pub String);

pub fn login(api: &mut Api, open_browser: bool) -> Result<KeyPassword, String> {
    println!("[fork] Fork-Sitzung anfordern");
    let init = api.get("/auth/v4/sessions/forks");
    if !init.ok() {
        return Err("Fork-Init fehlgeschlagen".into());
    }
    println!("  Felder: {:?}", init.field_names());
    let selector = str_field(&init.body, "Selector")?;
    let user_code = str_field(&init.body, "UserCode")?;

    let mut key = [0u8; 32];
    getrandom::fill(&mut key).map_err(|e| format!("Zufall: {e}"))?;
    let payload = format!("0:{user_code}:{}:{AUTH_CLIENT_ID}", STANDARD.encode(key));
    let url = format!(
        "{ACCOUNT_URL}/desktop/login?app=drive&pv=3#payload={}",
        percent_encode(&payload)
    );

    println!();
    println!("[fork] Bitte im Browser mit dem TESTKONTO anmelden und bestätigen:");
    println!("  {url}");
    println!("  (Der Schlüssel steht nur im #-Fragment und wird nicht an den Server gesendet.)");
    if open_browser {
        let _ = Command::new("xdg-open")
            .arg(&url)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn();
    }
    println!();

    let started = Instant::now();
    let mut pending_codes = Vec::new();
    let status = loop {
        sleep(POLL_INTERVAL);
        if started.elapsed() > MAX_POLL {
            return Err("Zeitüberschreitung (10 min) – Fork nicht bestätigt".into());
        }
        let r = api.get(&format!("/auth/v4/sessions/forks/{selector}"));
        if r.status.as_u16() == 422 {
            if !pending_codes.contains(&r.code) {
                pending_codes.push(r.code);
            }
            continue;
        }
        if !r.ok() {
            return Err(format!("Fork-Status unerwartet: HTTP {}", r.status));
        }
        break r;
    };
    println!(
        "[fork] bestätigt nach {} s; Pending-Codes beobachtet: {pending_codes:?}",
        started.elapsed().as_secs()
    );
    println!("  Felder: {:?}", status.field_names());
    if let Some(scopes) = status.body.get("Scopes").or_else(|| status.body.get("Scope")) {
        println!("  Scopes: {scopes}");
    }

    api.session = Some(Session {
        uid: str_field(&status.body, "UID")?,
        access_token: str_field(&status.body, "AccessToken")?,
        refresh_token: status
            .body
            .get("RefreshToken")
            .and_then(Value::as_str)
            .unwrap_or_default()
            .to_owned(),
    });
    let has_refresh = api.session.as_ref().is_some_and(|s| !s.refresh_token.is_empty());
    println!("  RefreshToken vorhanden: {has_refresh}");

    let key_password = decrypt_payload(&key, &str_field(&status.body, "Payload")?)?;
    println!("  keyPassword entschlüsselt: ja ({} Zeichen)", key_password.0.chars().count());
    Ok(key_password)
}

fn decrypt_payload(key: &[u8; 32], payload_b64: &str) -> Result<KeyPassword, String> {
    let blob = STANDARD.decode(payload_b64).map_err(|e| format!("Payload base64: {e}"))?;
    if blob.len() < 28 {
        return Err("Payload zu kurz".into());
    }
    let (nonce, ciphertext_and_tag) = blob.split_at(12);
    let cipher = Aes256Gcm::new_from_slice(key).map_err(|e| format!("AES-Key: {e}"))?;
    let plain = cipher
        .decrypt(
            nonce.try_into().map_err(|_| "Nonce-Länge")?,
            Payload { msg: ciphertext_and_tag, aad: b"fork" },
        )
        .map_err(|_| "Payload-Entschlüsselung fehlgeschlagen".to_owned())?;
    let json: Value = serde_json::from_slice(&plain).map_err(|e| format!("Payload JSON: {e}"))?;
    let fields: Vec<&String> = json.as_object().map(|m| m.keys().collect()).unwrap_or_default();
    println!("  Payload-Felder: {fields:?}");
    json.get("keyPassword")
        .and_then(Value::as_str)
        .map(|s| KeyPassword(s.to_owned()))
        .ok_or_else(|| "keyPassword fehlt".into())
}

fn str_field(body: &Value, name: &str) -> Result<String, String> {
    body.get(name)
        .and_then(Value::as_str)
        .map(str::to_owned)
        .ok_or_else(|| format!("Feld {name} fehlt"))
}

/// Wie JS `encodeURIComponent` für unseren Zeichensatz (Base64, `:`, alphanumerisch, `-`).
fn percent_encode(s: &str) -> String {
    let mut out = String::with_capacity(s.len() * 3);
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'!' | b'~' | b'*'
            | b'\'' | b'(' | b')' => out.push(char::from(b)),
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn encrypt(key: &[u8; 32], nonce: &[u8; 12], plain: &[u8], aad: &[u8]) -> String {
        let cipher = Aes256Gcm::new_from_slice(key).unwrap();
        let ct = cipher.encrypt(nonce.into(), Payload { msg: plain, aad }).unwrap();
        STANDARD.encode([nonce.as_slice(), &ct].concat())
    }

    #[test]
    fn decrypts_fork_payload() {
        let key = [7u8; 32];
        let blob = encrypt(&key, &[1; 12], br#"{"type":"default","keyPassword":"geheim"}"#, b"fork");
        assert_eq!(decrypt_payload(&key, &blob).unwrap().0, "geheim");
    }

    #[test]
    fn rejects_wrong_aad_or_key() {
        let key = [7u8; 32];
        let blob = encrypt(&key, &[1; 12], br#"{"keyPassword":"x"}"#, b"nope");
        assert!(decrypt_payload(&key, &blob).is_err());
        let blob = encrypt(&key, &[1; 12], br#"{"keyPassword":"x"}"#, b"fork");
        assert!(decrypt_payload(&[8u8; 32], &blob).is_err());
        assert!(decrypt_payload(&key, "AAAA").is_err());
    }

    #[test]
    fn percent_encodes_like_encode_uri_component() {
        assert_eq!(percent_encode("0:AB12:a+b/c=:external-drive"), "0%3AAB12%3Aa%2Bb%2Fc%3D%3Aexternal-drive");
    }
}
