//! P2-05: Drive schreiben – Ordner, Datei (Block-Upload + Revision), Duplikat, Events, Löschen.
//!
//! Format bewusst „pre-crypto-refresh" (wie rclone/offizielle Apps es derzeit lesen):
//! v4-Node-Keys, PKESK v3 + SEIPD v1, keine AEAD. Das Default-Profil des Rust-Backends tut das.

use std::{
    io::{BufRead, Write as _},
    time::{Instant, SystemTime, UNIX_EPOCH},
};

use base64::{engine::general_purpose::STANDARD, Engine};
use hmac::{Hmac, KeyInit, Mac};
use proton_crypto::crypto::{
    DataEncoding, Encryptor, EncryptorSync, KeyGenerator, KeyGeneratorSync, PGPProviderSync,
    SessionKeyAlgorithm, Signer, SignerSync,
};
use reqwest::{blocking::multipart, Method};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};

use crate::{
    api::{Api, APP_VERSION},
    drive::{self, keys_of, str_of, DriveCtx},
    fork::KeyPassword,
};

pub const PROBE_FOLDER: &str = "TasksProbe";

/// Signierschlüssel: primärer Adress-Key des Shares.
fn signing_key<P: PGPProviderSync>(ctx: &DriveCtx<P>) -> &P::PrivateKey {
    let key = ctx.address_keys.iter().find(|k| k.primary).unwrap_or(&ctx.address_keys[0]);
    &key.private_key
}

pub struct NewNode<P: PGPProviderSync> {
    pub key: P::PrivateKey,
    pub fields: Value,
}

/// Erzeugt Node-Key + Passphrase und die Felder Name, Hash, NodeKey, NodePassphrase(+Signatur).
pub fn new_node<P: PGPProviderSync>(
    p: &P,
    parent_key: &P::PrivateKey,
    parent_hash_key: &[u8],
    address_key: &P::PrivateKey,
    name: &str,
) -> Result<NewNode<P>, String> {
    let mut raw = [0u8; 32];
    getrandom::fill(&mut raw).map_err(|e| e.to_string())?;
    let passphrase = STANDARD.encode(raw);
    let key = p
        .new_key_generator()
        .with_user_id("Drive key", "noreply@protonmail.com")
        .generate()
        .map_err(|e| format!("Key-Erzeugung: {e}"))?;
    let locked = p
        .private_key_export(&key, passphrase.as_bytes(), DataEncoding::Armor)
        .map_err(|e| format!("Key-Export: {e}"))?
        .as_ref()
        .to_vec();
    let fields = json!({
        "Name": encrypt_armored(p, parent_key, name.as_bytes(), Some(address_key))?,
        "Hash": name_hash(parent_hash_key, name),
        "NodeKey": String::from_utf8_lossy(&locked),
        "NodePassphrase": encrypt_armored(p, parent_key, passphrase.as_bytes(), None)?,
        "NodePassphraseSignature": sign_armored(p, address_key, passphrase.as_bytes())?,
    });
    Ok(NewNode { key, fields })
}

/// Verschlüsselt an den (öffentlichen Teil von) `recipient`, optional signiert. Armiert.
pub fn encrypt_armored<P: PGPProviderSync>(
    p: &P,
    recipient: &P::PrivateKey,
    data: &[u8],
    signer: Option<&P::PrivateKey>,
) -> Result<String, String> {
    let public = p.private_key_to_public_key(recipient).map_err(|e| e.to_string())?;
    let mut enc = p.new_encryptor().with_encryption_key(&public);
    if let Some(s) = signer {
        enc = enc.with_signing_key(s);
    }
    let out = enc.encrypt_raw(data, DataEncoding::Armor).map_err(|e| format!("Verschlüsseln: {e}"))?;
    String::from_utf8(out).map_err(|e| e.to_string())
}

pub fn sign_armored<P: PGPProviderSync>(p: &P, key: &P::PrivateKey, data: &[u8]) -> Result<String, String> {
    let sig = p
        .new_signer()
        .with_signing_key(key)
        .sign_detached(data, DataEncoding::Armor)
        .map_err(|e| format!("Signieren: {e}"))?;
    String::from_utf8(sig).map_err(|e| e.to_string())
}

pub fn name_hash(hash_key: &[u8], name: &str) -> String {
    let mut mac = <Hmac<Sha256> as KeyInit>::new_from_slice(hash_key).expect("HMAC akzeptiert jede Länge");
    mac.update(name.as_bytes());
    hex::encode(mac.finalize().into_bytes())
}

/// Ordner-spezifisch: zufälliger Hash-Key, an den eigenen Node-Key verschlüsselt und signiert.
pub fn folder_hash_key<P: PGPProviderSync>(p: &P, node_key: &P::PrivateKey) -> Result<String, String> {
    // Wie bei den offiziellen Clients: der Base64-Text von 32 Zufallsbytes (44 Bytes) ist der Schlüssel.
    let mut raw = [0u8; 32];
    getrandom::fill(&mut raw).map_err(|e| e.to_string())?;
    encrypt_armored(p, node_key, STANDARD.encode(raw).as_bytes(), Some(node_key))
}

pub struct FileContent<P: PGPProviderSync> {
    pub session_key: P::SessionKey,
    pub key_packet_b64: String,
    pub key_packet_signature: String,
}

pub fn file_content_key<P: PGPProviderSync>(p: &P, node_key: &P::PrivateKey) -> Result<FileContent<P>, String> {
    let session_key = p
        .session_key_generate(SessionKeyAlgorithm::Aes256)
        .map_err(|e| format!("Session-Key: {e}"))?;
    let public = p.private_key_to_public_key(node_key).map_err(|e| e.to_string())?;
    let packets = p
        .new_encryptor()
        .with_encryption_key(&public)
        .encrypt_session_key(&session_key)
        .map_err(|e| format!("Key-Packet: {e}"))?;
    let raw = p.session_key_export(&session_key).map_err(|e| e.to_string())?.0.as_ref().to_vec();
    let key_packet_signature = sign_armored(p, node_key, &raw)?;
    Ok(FileContent { session_key, key_packet_b64: STANDARD.encode(packets), key_packet_signature })
}

/// Verifikations-Token: `code XOR data[..code.len()]` (fehlende Bytes als 0 aufgefüllt).
pub fn verification_token(code: &[u8], data_packet: &[u8]) -> Vec<u8> {
    code.iter().enumerate().map(|(i, c)| c ^ data_packet.get(i).copied().unwrap_or(0)).collect()
}

pub struct EncBlock {
    pub data: Vec<u8>,
    pub hash: Vec<u8>,
    pub enc_signature: String,
}

/// Verschlüsselt einen Block mit dem Session-Key (nur Datenpaket) und signiert den Klartext
/// mit dem Adress-Key; die Signatur wird an den Node-Key verschlüsselt.
pub fn encrypt_block<P: PGPProviderSync>(
    p: &P,
    session_key: &P::SessionKey,
    node_key: &P::PrivateKey,
    address_key: &P::PrivateKey,
    plain: &[u8],
) -> Result<EncBlock, String> {
    let data = p
        .new_encryptor()
        .with_session_key_ref(session_key)
        .encrypt_raw(plain, DataEncoding::Bytes)
        .map_err(|e| format!("Block verschlüsseln: {e}"))?;
    let raw_sig = p
        .new_signer()
        .with_signing_key(address_key)
        .sign_detached(plain, DataEncoding::Bytes)
        .map_err(|e| format!("Block signieren: {e}"))?;
    let enc_signature = encrypt_armored(p, node_key, &raw_sig, None)?;
    let hash = Sha256::digest(&data).to_vec();
    Ok(EncBlock { data, hash, enc_signature })
}

// ---------------------------------------------------------------------------------------------

struct Timings(Vec<(&'static str, u128)>);

impl Timings {
    fn add(&mut self, what: &'static str, started: Instant) {
        self.0.push((what, started.elapsed().as_millis()));
    }
}

pub fn cmd_write(api: &Api, key_password: &KeyPassword) -> Result<(), String> {
    let ctx = drive::open(api, key_password)?;
    let p = &ctx.provider;
    let addr_key = signing_key(&ctx);
    let mut t = Timings(Vec::new());

    // Event-Cursor vor den Änderungen.
    println!("\n[events] Cursor vor den Änderungen");
    let latest = api.get(&format!("/drive/volumes/{}/events/latest", ctx.volume_id));
    println!("  Felder: {:?}", latest.field_names());
    let event_id = latest.body["EventID"].as_str().map(str::to_owned);

    // 1. Ordner finden oder anlegen.
    println!("\n[p2-05] Ordner {PROBE_FOLDER}/");
    let started = Instant::now();
    let entries = drive::list_root(api, &ctx)?;
    t.add("Listing Root (children + Namen entschlüsseln)", started);
    let (folder_id, folder_key, folder_hash_key) =
        match entries.iter().find(|(l, n)| n == PROBE_FOLDER && l["Type"].as_i64() == Some(1)) {
            Some((link, _)) => {
                println!("  vorhanden – wird wiederverwendet");
                let key = drive::unlock_node(p, &[&ctx.root_key], &ctx.address_keys, link)?;
                let hk = drive::decrypt_hash_key(p, &key, link)?;
                (str_of(link, "LinkID")?, key, hk)
            }
            None => {
                let node = new_node(p, &ctx.root_key, &ctx.root_hash_key, addr_key, PROBE_FOLDER)?;
                let hash_key_armored = folder_hash_key(p, &node.key)?;
                let mut body = node.fields;
                body["ParentLinkID"] = json!(ctx.root_link_id);
                body["NodeHashKey"] = json!(hash_key_armored);
                body["SignatureAddress"] = json!(ctx.address_email);
                let started = Instant::now();
                let r = api.call(Method::POST, &format!("/drive/shares/{}/folders", ctx.share_id), Some(&body), &[]);
                t.add("Ordner anlegen", started);
                if !r.ok() {
                    return Err("Ordner anlegen fehlgeschlagen".into());
                }
                println!("  angelegt; Antwort-Felder: {:?}", r.field_names());
                let id = str_of(&r.body["Folder"], "ID")?;
                let link = json!({ "FolderProperties": { "NodeHashKey": hash_key_armored } });
                let hk = drive::decrypt_hash_key(p, &node.key, &link)?;
                (id, node.key, hk)
            }
        };

    // 2. Datei hochladen.
    let ts = SystemTime::now().duration_since(UNIX_EPOCH).map_err(|e| e.to_string())?.as_secs();
    let file_name = format!("hello-{ts}.bin");
    let mut plain = format!("Hallo von der tasksprobe ({file_name}).\n").into_bytes();
    plain.resize(1024, b'.');
    println!("\n[p2-05] Datei {PROBE_FOLDER}/{file_name} ({} Bytes) hochladen", plain.len());
    let upload_started = Instant::now();
    let node = new_node(p, &folder_key, &folder_hash_key, addr_key, &file_name)?;
    let content = file_content_key(p, &node.key)?;
    let mut body = node.fields.clone();
    body["ParentLinkID"] = json!(folder_id);
    body["MIMEType"] = json!("application/octet-stream");
    body["ContentKeyPacket"] = json!(content.key_packet_b64);
    body["ContentKeyPacketSignature"] = json!(content.key_packet_signature);
    body["SignatureAddress"] = json!(ctx.address_email);
    let create_path = format!("/drive/shares/{}/files", ctx.share_id);
    let r = api.call(Method::POST, &create_path, Some(&body), &[]);
    if !r.ok() {
        return Err("Datei anlegen fehlgeschlagen".into());
    }
    println!("  Antwort-Felder: {:?} / File: {:?}", r.field_names(), keys_of(&r.body["File"]));
    let link_id = str_of(&r.body["File"], "ID")?;
    let revision_id = str_of(&r.body["File"], "RevisionID")?;

    let block = encrypt_block(p, &content.session_key, &node.key, addr_key, &plain)?;

    // Block-Verifikation (seit 2026 Pflicht): Server liefert pro Revision einen Code; Token je Block
    // = Code XOR Anfang des verschlüsselten Datenpakets.
    let v = api.get(&format!(
        "/drive/v2/volumes/{}/links/{link_id}/revisions/{revision_id}/verification",
        ctx.volume_id
    ));
    if !v.ok() {
        return Err("Verifikationsdaten nicht abrufbar".into());
    }
    println!("  Verifikation-Felder: {:?}", v.field_names());
    let code = STANDARD
        .decode(str_of(&v.body, "VerificationCode")?)
        .map_err(|e| format!("VerificationCode base64: {e}"))?;
    println!("  VerificationCode: {} Bytes", code.len());
    let token = verification_token(&code, &block.data);

    let req = json!({
        "AddressID": ctx.address_id,
        "VolumeID": ctx.volume_id,
        "LinkID": link_id,
        "RevisionID": revision_id,
        "BlockList": [{
            "Index": 1,
            "Size": block.data.len(),
            "EncSignature": block.enc_signature,
            "Hash": STANDARD.encode(&block.hash),
            "Verifier": { "Token": STANDARD.encode(token) },
        }],
        "ThumbnailList": [],
    });
    let r = api.call(Method::POST, "/drive/blocks", Some(&req), &[]);
    if !r.ok() {
        return Err("Block-Upload anfordern fehlgeschlagen".into());
    }
    println!("  Antwort-Felder: {:?}", r.field_names());
    let link = r.body["UploadLinks"].get(0).ok_or("keine UploadLinks")?;
    let form = multipart::Form::new().part(
        "Block",
        multipart::Part::bytes(block.data.clone())
            .file_name("blob")
            .mime_str("application/octet-stream")
            .map_err(|e| e.to_string())?,
    );
    let started = Instant::now();
    let up = api
        .http
        .post(str_of(link, "BareURL")?)
        .header("pm-storage-token", str_of(link, "Token")?)
        .header("x-pm-appversion", APP_VERSION)
        .multipart(form)
        .send()
        .map_err(|e| format!("Block-Upload: {e}"))?;
    println!("  → POST   <storage-url>  HTTP {}  {} ms", up.status().as_u16(), started.elapsed().as_millis());
    if !up.status().is_success() {
        return Err("Block-Upload fehlgeschlagen".into());
    }

    let xattr = json!({ "Common": {
        "ModificationTime": iso_now(ts),
        "Size": plain.len(),
        "BlockSizes": [plain.len()],
        "Digests": { "SHA1": hex::encode(sha1::Sha1::digest(&plain)) },
    }});
    let commit = json!({
        "ManifestSignature": sign_armored(p, addr_key, &block.hash)?,
        "SignatureAddress": ctx.address_email,
        "ChecksumVerified": true,
        "XAttr": encrypt_armored(p, &node.key, xattr.to_string().as_bytes(), Some(addr_key))?,
    });
    let r = api.call(
        Method::PUT,
        &format!("/drive/v2/volumes/{}/files/{link_id}/revisions/{revision_id}", ctx.volume_id),
        Some(&commit),
        &[],
    );
    if !r.ok() {
        return Err("Revision committen fehlgeschlagen".into());
    }
    t.add("Upload 1 KB gesamt (anlegen + Block + Commit, inkl. Krypto)", upload_started);

    // 3. Gegenprobe: zurücklesen.
    println!("\n[p2-05] Zurücklesen");
    let started = Instant::now();
    let r = api.get(&format!("/drive/shares/{}/links/{link_id}", ctx.share_id));
    let file_link = r.body.get("Link").ok_or("Link fehlt")?.clone();
    let folder_ctx_keys = [&folder_key];
    let back = drive::read_file_with(api, &ctx, &folder_ctx_keys, &file_link)?;
    t.add("Download 1 KB gesamt (Link + Revision + Block, inkl. Krypto)", started);
    println!("  Inhalt identisch: {}", back == plain);

    // 4. Duplikat: gleicher Name noch einmal.
    println!("\n[p2-05] Duplikat (gleicher Name) anlegen – erwarteter Fehler");
    let dup = api.call(Method::POST, &create_path, Some(&body), &[]);
    println!("  → HTTP {}  Code={:?}", dup.status.as_u16(), dup.code);

    // 5. Events seit Cursor.
    if let Some(id) = event_id {
        println!("\n[events] Änderungen seit Cursor");
        for path in [
            format!("/drive/volumes/{}/events/{id}", ctx.volume_id),
            format!("/drive/v2/volumes/{}/events/{id}", ctx.volume_id),
        ] {
            let r = api.get(&path);
            let events = r.body["Events"].as_array().cloned().unwrap_or_default();
            println!("  Felder: {:?}; Events: {}", r.field_names(), events.len());
            for e in events.iter().take(10) {
                println!(
                    "    EventType={}  Felder={:?}  Link-Felder={:?}",
                    e["EventType"],
                    keys_of(e),
                    keys_of(&e["Link"])
                );
            }
        }
    }

    // 6. Manuelle Prüfung im Web, dann löschen.
    println!("\n>>> Bitte jetzt in der Proton-Drive-Weboberfläche {PROBE_FOLDER}/{file_name} öffnen");
    println!(">>> und prüfen, ob der Inhalt lesbar ist. Danach hier Enter drücken (Datei wird gelöscht).");
    let _ = std::io::stdout().flush();
    let mut line = String::new();
    let _ = std::io::stdin().lock().read_line(&mut line);

    println!("\n[p2-05] Löschen (Papierkorb, dann endgültig)");
    let ids = json!({ "LinkIDs": [link_id] });
    let started = Instant::now();
    let trash = api.call(
        Method::POST,
        &format!("/drive/shares/{}/folders/{folder_id}/trash_multiple", ctx.share_id),
        Some(&ids),
        &[],
    );
    println!("  Papierkorb: Felder {:?}", trash.field_names());
    let del = api.call(
        Method::POST,
        &format!("/drive/shares/{}/folders/{folder_id}/delete_multiple", ctx.share_id),
        Some(&ids),
        &[],
    );
    println!("  Endgültig: Felder {:?}; Responses: {}", del.field_names(), del.body["Responses"]);
    t.add("Löschen (trash + delete)", started);

    println!("\n[p2-05] Latenzen");
    for (what, ms) in &t.0 {
        println!("  {ms:>6} ms  {what}");
    }
    Ok(())
}

fn iso_now(unix: u64) -> String {
    // Ohne Datums-Crate: Tage seit Epoche → Datum (proleptisch gregorianisch).
    let (days, secs) = ((unix / 86_400) as i64, unix % 86_400);
    let z = days + 719_468;
    let era = z.div_euclid(146_097);
    let doe = z.rem_euclid(146_097);
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    let y = yoe + era * 400 + i64::from(m <= 2);
    format!("{y:04}-{m:02}-{d:02}T{:02}:{:02}:{:02}+0000", secs / 3600, secs % 3600 / 60, secs % 60)
}

#[cfg(test)]
mod tests {
    //! Offline-Roundtrip: Was der Schreibpfad erzeugt, muss der Lesepfad lesen können.
    use proton_crypto::crypto::{AsPublicKeyRef, Decryptor, DecryptorSync, VerifiedData, Verifier, VerifierSync};
    use proton_crypto_account::keys::{DecryptedAddressKey, KeyFlag};

    use super::*;

    /// Liest Tag und Versionsbyte des ersten OpenPGP-Pakets (neues oder altes Header-Format).
    fn packet_version(bytes: &[u8], expected_tag: u8) -> u8 {
        let h = bytes[0];
        assert!(h & 0x80 != 0, "kein OpenPGP-Paket");
        let (tag, body) = if h & 0x40 != 0 {
            let l = bytes[1];
            let off = match l {
                0..=191 => 2,
                192..=223 => 3,
                255 => 6,
                _ => 2, // partielle Länge: erstes Teilstück folgt direkt
            };
            (h & 0x3f, off)
        } else {
            let off = match h & 0x03 { 0 => 2, 1 => 3, 2 => 5, _ => 1 };
            ((h >> 2) & 0x0f, off)
        };
        assert_eq!(tag, expected_tag, "Pakettyp");
        bytes[body]
    }

    #[test]
    fn verification_token_xors_prefix_and_pads() {
        assert_eq!(verification_token(&[0xff, 0x0f, 0x00], &[0x01, 0x02, 0x03, 0x04]), [0xfe, 0x0d, 0x03]);
        assert_eq!(verification_token(&[0xaa, 0xbb], &[0x01]), [0xab, 0xbb], "auffüllen mit 0");
    }

    #[test]
    fn iso_date() {
        assert_eq!(iso_now(0), "1970-01-01T00:00:00+0000");
        assert_eq!(iso_now(1_760_710_496), "2025-10-17T14:14:56+0000");
    }

    #[test]
    fn name_hash_is_hex_hmac() {
        // RFC 4231, Testfall 2.
        assert_eq!(
            name_hash(b"Jefe", "what do ya want for nothing?"),
            "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843"
        );
    }

    #[test]
    fn write_then_read_roundtrip() {
        let p = proton_crypto::new_pgp_provider();
        let gen = |n: &str| p.new_key_generator().with_user_id(n, "x@example.org").generate().unwrap();
        let addr_priv = gen("addr");
        let addr = DecryptedAddressKey {
            id: proton_crypto_account::keys::KeyId::from("a"),
            flags: KeyFlag::default(),
            primary: true,
            is_v6: false,
            public_key: p.private_key_to_public_key(&addr_priv).unwrap(),
            private_key: addr_priv.clone(),
        };
        let address_keys = vec![addr];
        let parent = gen("parent");
        let parent_hash_key = [9u8; 32];

        // Ordner schreiben → lesen.
        let folder = new_node(&p, &parent, &parent_hash_key, &addr_priv, "TasksProbe").unwrap();
        let mut link = folder.fields.clone();
        link["FolderProperties"] = json!({ "NodeHashKey": folder_hash_key(&p, &folder.key).unwrap() });
        let key = drive::unlock_node(&p, &[&parent], &address_keys, &link).unwrap();
        assert_eq!(drive::decrypt_name(&p, &[&parent], &address_keys, &link).unwrap(), "TasksProbe");
        let hash_key = drive::decrypt_hash_key(&p, &key, &link).unwrap();
        assert_eq!(hash_key.len(), 44, "Base64-Text wie bei offiziellen Clients");
        assert_eq!(link["Hash"], json!(name_hash(&parent_hash_key, "TasksProbe")));

        // Datei schreiben → Session-Key + Block lesen.
        let file = new_node(&p, &key, &hash_key, &addr_priv, "hello.bin").unwrap();
        let content = file_content_key(&p, &file.key).unwrap();
        let file_key = drive::unlock_node(&p, &[&key], &address_keys, &file.fields).unwrap();
        let packet = STANDARD.decode(&content.key_packet_b64).unwrap();
        let sk = p.new_decryptor().with_decryption_key(&file_key).decrypt_session_key(&packet).unwrap();
        let plain = b"hallo welt".repeat(100);
        let block = encrypt_block(&p, &content.session_key, &file.key, &addr_priv, &plain).unwrap();
        let back = p.new_decryptor().with_session_key_ref(&sk).decrypt(&block.data, DataEncoding::Bytes).unwrap();
        assert_eq!(back.as_bytes(), plain.as_slice());

        // Block-Signatur: an Node-Key verschlüsselt, mit Adress-Key verifizierbar.
        let sig = p.new_decryptor().with_decryption_key(&file_key).decrypt(&block.enc_signature, DataEncoding::Armor).unwrap();
        let ok = p
            .new_verifier()
            .with_verification_keys(address_keys.iter().map(AsPublicKeyRef::as_public_key))
            .verify_detached(&plain, sig.as_bytes(), DataEncoding::Bytes);
        assert!(ok.is_ok());
        // Format „pre-crypto-refresh": v4-Key, PKESK v3, SEIPD v1 (keine AEAD).
        use proton_crypto::crypto::AccessKeyInfo;
        assert_eq!(file.key.version(), 4);
        assert_eq!(packet_version(&packet, 1), 3, "PKESK v3");
        assert_eq!(packet_version(&block.data, 18), 1, "SEIPD v1");

        // Content-Key-Signatur mit dem Node-Key.
        let (raw, _) = p.session_key_export(&sk).unwrap();
        let pub_node = p.private_key_to_public_key(&file_key).unwrap();
        assert!(p.new_verifier().with_verification_key(&pub_node).verify_detached(raw.as_ref(), &content.key_packet_signature, DataEncoding::Armor).is_ok());
    }
}
