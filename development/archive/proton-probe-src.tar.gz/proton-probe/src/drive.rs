//! P2-04: Drive lesen – Schlüsselkette aufbauen, Root-Ordner listen, Datei entschlüsseln.
//!
//! Kette: keyPassword → User-Keys → Adress-Keys → Share-Key → Node-Keys → Namen/Inhalte.

use base64::{engine::general_purpose::STANDARD, Engine};
use proton_crypto::crypto::{
    AsPublicKeyRef, DataEncoding, Decryptor, DecryptorSync, PGPProviderSync, VerifiedData,
    Verifier, VerifierSync,
};
use proton_crypto_account::{
    keys::{AddressKeys, LockedKey, UnlockedAddressKey, UnlockedUserKey, UserKeys},
    salts::KeySecret,
};
use serde_json::Value;

use crate::{
    api::{download_block, Api},
    fork::KeyPassword,
};

/// Entsperrter Zugang zum Haupt-Share – Grundlage für Lesen (P2-04) und Schreiben (P2-05).
pub struct DriveCtx<P: PGPProviderSync> {
    pub provider: P,
    pub volume_id: String,
    pub share_id: String,
    pub root_link_id: String,
    pub address_id: String,
    pub address_email: String,
    pub address_keys: Vec<UnlockedAddressKey<P>>,
    pub root_key: P::PrivateKey,
    pub root_hash_key: Vec<u8>,
}

pub fn open(api: &Api, key_password: &KeyPassword) -> Result<DriveCtx<impl PGPProviderSync>, String> {
    open_with(proton_crypto::new_pgp_provider(), api, key_password)
}

fn open_with<P: PGPProviderSync>(
    provider: P,
    api: &Api,
    key_password: &KeyPassword,
) -> Result<DriveCtx<P>, String> {
    let secret = KeySecret::new(key_password.0.as_bytes().to_vec());

    println!("\n[keys] User-Keys");
    let users = api.get("/core/v4/users");
    let locked: Vec<LockedKey> = from_field(&users.body["User"], "Keys")?;
    let user_unlock = UserKeys::new(locked).unlock(&provider, &secret);
    println!(
        "  entsperrt: {}, fehlgeschlagen: {}",
        user_unlock.unlocked_keys.len(),
        user_unlock.failed.len()
    );
    let user_keys: Vec<UnlockedUserKey<P>> = user_unlock.unlocked_keys;
    if user_keys.is_empty() {
        return Err("kein User-Key entsperrt".into());
    }

    println!("\n[drive] Volume und Haupt-Share");
    let volumes = api.get("/drive/volumes");
    let volume = volumes.body["Volumes"].get(0).ok_or("kein Volume")?.clone();
    println!("  Volume-Felder: {:?}", keys_of(&volume));
    let volume_id = str_of(&volume, "VolumeID")?;
    let share_id = str_of(&volume["Share"], "ShareID")?;
    let root_link_id = str_of(&volume["Share"], "LinkID")?;

    let share = api.get(&format!("/drive/shares/{share_id}"));
    if !share.ok() {
        return Err("Share nicht lesbar".into());
    }
    println!("  Share-Felder: {:?}", share.field_names());
    let address_id = str_of(&share.body, "AddressID")?;

    println!("\n[keys] Adress-Keys (Adresse des Shares)");
    let addresses = api.get("/core/v4/addresses");
    let address = addresses.body["Addresses"]
        .as_array()
        .and_then(|a| a.iter().find(|x| x["ID"].as_str() == Some(address_id.as_str())))
        .ok_or("Share-Adresse nicht gefunden")?;
    let address_email = str_of(address, "Email")?;
    let locked: Vec<LockedKey> = from_field(address, "Keys")?;
    let addr_unlock = AddressKeys::new(locked).unlock(&provider, &user_keys, Some(&secret));
    println!(
        "  entsperrt: {}, fehlgeschlagen: {}, v6: {}",
        addr_unlock.unlocked_keys.len(),
        addr_unlock.failed.len(),
        addr_unlock.unlocked_keys.iter().filter(|k| k.is_v6).count()
    );
    let address_keys = addr_unlock.unlocked_keys;
    if address_keys.is_empty() {
        return Err("kein Adress-Key entsperrt".into());
    }

    println!("\n[keys] Share-Key");
    let addr_priv: Vec<&_> = address_keys.iter().map(|k| &k.private_key).collect();
    let share_pass = decrypt_verified(
        &provider,
        &addr_priv,
        &address_keys,
        &str_of(&share.body, "Passphrase")?,
        Some(&str_of(&share.body, "PassphraseSignature")?),
    )?;
    let share_key = provider
        .private_key_import(str_of(&share.body, "Key")?, &share_pass, DataEncoding::Armor)
        .map_err(|e| format!("Share-Key: {e}"))?;
    println!("  Share-Key entsperrt");

    println!("\n[drive] Root-Ordner");
    let root = api.get(&format!("/drive/shares/{share_id}/links/{root_link_id}"));
    let root_link = root.body.get("Link").ok_or("Root-Link fehlt")?;
    println!("  Link-Felder: {:?}", keys_of(root_link));
    let root_key = unlock_node(&provider, &[&share_key], &address_keys, root_link)?;
    let root_name = decrypt_name(&provider, &[&share_key], &address_keys, root_link)?;
    println!("  Root-Name: {root_name:?}");
    let root_hash_key = decrypt_hash_key(&provider, &root_key, root_link)?;
    println!("  NodeHashKey entschlüsselt ({} Bytes)", root_hash_key.len());

    Ok(DriveCtx {
        provider,
        volume_id,
        share_id,
        root_link_id,
        address_id,
        address_email,
        address_keys,
        root_key,
        root_hash_key,
    })
}

/// Listet die Kinder des Root-Ordners und gibt (Link, Klarname) zurück.
pub fn list_root<P: PGPProviderSync>(api: &Api, ctx: &DriveCtx<P>) -> Result<Vec<(Value, String)>, String> {
    let r = api.get(&format!(
        "/drive/shares/{}/folders/{}/children?Page=0&PageSize=150&ShowAll=0",
        ctx.share_id, ctx.root_link_id
    ));
    let links = r.body["Links"].as_array().cloned().unwrap_or_default();
    let mut out = Vec::new();
    for link in links {
        let name = decrypt_name(&ctx.provider, &[&ctx.root_key], &ctx.address_keys, &link)
            .unwrap_or_else(|e| format!("<{e}>"));
        out.push((link, name));
    }
    Ok(out)
}

pub fn cmd_read(api: &Api, key_password: &KeyPassword, file: Option<&str>) -> Result<(), String> {
    let ctx = open(api, key_password)?;
    println!("\n[drive] Inhalt des Root-Ordners");
    let entries = list_root(api, &ctx)?;
    for (link, name) in &entries {
        let kind = if link["Type"].as_i64() == Some(1) { "Ordner" } else { "Datei " };
        println!("  [{kind}] {name}  ({} Bytes)", link["Size"].as_i64().unwrap_or(0));
    }

    let Some(wanted) = file else {
        println!("\n(Keine Datei angegeben – mit `drive-read <Dateiname>` herunterladen.)");
        return Ok(());
    };
    let (link, _) = entries
        .iter()
        .find(|(l, n)| n == wanted && l["Type"].as_i64() == Some(2))
        .ok_or_else(|| format!("Datei {wanted:?} nicht im Root-Ordner"))?;
    println!("\n[drive] Datei {wanted:?} herunterladen");
    println!("  Link-Felder: {:?}", keys_of(link));
    let content = read_file(api, &ctx, link)?;
    println!("\n----- Inhalt ({} Bytes) -----", content.len());
    println!("{}", String::from_utf8_lossy(&content));
    println!("----- Ende -----");
    Ok(())
}

pub fn read_file<P: PGPProviderSync>(api: &Api, ctx: &DriveCtx<P>, link: &Value) -> Result<Vec<u8>, String> {
    read_file_with(api, ctx, &[&ctx.root_key], link)
}

/// Liest eine Datei, deren Elternordner-Key(s) `parent_keys` sind.
pub fn read_file_with<P: PGPProviderSync>(
    api: &Api,
    ctx: &DriveCtx<P>,
    parent_keys: &[&P::PrivateKey],
    link: &Value,
) -> Result<Vec<u8>, String> {
    let p = &ctx.provider;
    let node_key = unlock_node(p, parent_keys, &ctx.address_keys, link)?;
    let props = &link["FileProperties"];
    let key_packet = STANDARD
        .decode(str_of(props, "ContentKeyPacket")?)
        .map_err(|e| format!("ContentKeyPacket base64: {e}"))?;
    let session_key = p
        .new_decryptor()
        .with_decryption_key(&node_key)
        .decrypt_session_key(&key_packet)
        .map_err(|e| format!("Session-Key: {e}"))?;
    println!("  Session-Key entschlüsselt");

    let link_id = str_of(link, "LinkID")?;
    let rev_id = str_of(&props["ActiveRevision"], "ID")?;
    let rev = api.get(&format!(
        "/drive/shares/{}/files/{link_id}/revisions/{rev_id}?FromBlockIndex=1&PageSize=50",
        ctx.share_id
    ));
    let revision = rev.body.get("Revision").ok_or("Revision fehlt")?;
    println!("  Revision-Felder: {:?}", keys_of(revision));
    let mut blocks = revision["Blocks"].as_array().cloned().unwrap_or_default();
    blocks.sort_by_key(|b| b["Index"].as_i64());
    if let Some(b) = blocks.first() {
        println!("  Block-Felder: {:?}", keys_of(b));
    }

    let mut content = Vec::new();
    for block in &blocks {
        let enc = download_block(api, &str_of(block, "BareURL")?, &str_of(block, "Token")?)?;
        let plain = p
            .new_decryptor()
            .with_session_key_ref(&session_key)
            .decrypt(&enc, DataEncoding::Bytes)
            .map_err(|e| format!("Block entschlüsseln: {e}"))?;
        content.extend_from_slice(plain.as_bytes());
    }
    Ok(content)
}

/// Entschlüsselt den `NodeHashKey` eines Ordners (an den eigenen Node-Key verschlüsselt).
pub fn decrypt_hash_key<P: PGPProviderSync>(
    p: &P,
    node_key: &P::PrivateKey,
    link: &Value,
) -> Result<Vec<u8>, String> {
    let data = p
        .new_decryptor()
        .with_decryption_key(node_key)
        .decrypt(str_of(&link["FolderProperties"], "NodeHashKey")?, DataEncoding::Armor)
        .map_err(|e| format!("NodeHashKey: {e}"))?;
    Ok(data.as_bytes().to_vec())
}

/// Entsperrt den Node-Key eines Links mit den Schlüsseln des Elternknotens.
pub fn unlock_node<P: PGPProviderSync>(
    p: &P,
    parent_keys: &[&P::PrivateKey],
    address_keys: &[UnlockedAddressKey<P>],
    link: &Value,
) -> Result<P::PrivateKey, String> {
    let passphrase = decrypt_verified(
        p,
        parent_keys,
        address_keys,
        &str_of(link, "NodePassphrase")?,
        link["NodePassphraseSignature"].as_str(),
    )?;
    p.private_key_import(str_of(link, "NodeKey")?, &passphrase, DataEncoding::Armor)
        .map_err(|e| format!("Node-Key: {e}"))
}

/// Entschlüsselt einen Namen (verschlüsselt an den Elternknoten, signiert mit Adress-Key).
pub fn decrypt_name<P: PGPProviderSync>(
    p: &P,
    parent_keys: &[&P::PrivateKey],
    address_keys: &[UnlockedAddressKey<P>],
    link: &Value,
) -> Result<String, String> {
    let data = p
        .new_decryptor()
        .with_decryption_keys(parent_keys.iter().copied())
        .with_verification_key_refs(address_keys)
        .decrypt(str_of(link, "Name")?, DataEncoding::Armor)
        .map_err(|e| format!("Name: {e}"))?;
    if !data.is_verified() {
        // Signatur kann auch von einem anderen Adress-Key stammen; nur melden.
        print!("  (Namenssignatur nicht verifiziert) ");
    }
    Ok(String::from_utf8_lossy(data.as_bytes()).into_owned())
}

/// Entschlüsselt eine armierte Nachricht; prüft optional eine separate (armierte) Signatur.
fn decrypt_verified<P: PGPProviderSync>(
    p: &P,
    keys: &[&P::PrivateKey],
    address_keys: &[UnlockedAddressKey<P>],
    message: &str,
    detached_signature: Option<&str>,
) -> Result<Vec<u8>, String> {
    let data = p
        .new_decryptor()
        .with_decryption_keys(keys.iter().copied())
        .decrypt(message, DataEncoding::Armor)
        .map_err(|e| format!("Entschlüsselung: {e}"))?;
    let bytes = data.as_bytes().to_vec();
    if let Some(sig) = detached_signature {
        let verified = p
            .new_verifier()
            .with_verification_keys(address_keys.iter().map(AsPublicKeyRef::as_public_key))
            .verify_detached(&bytes, sig, DataEncoding::Armor)
            .is_ok();
        if !verified {
            println!("  WARNUNG: Signatur nicht verifiziert");
        }
    }
    Ok(bytes)
}

fn from_field<T: serde::de::DeserializeOwned>(obj: &Value, field: &str) -> Result<T, String> {
    serde_json::from_value(obj.get(field).cloned().unwrap_or(Value::Null))
        .map_err(|e| format!("{field}: {e}"))
}

pub fn str_of(obj: &Value, field: &str) -> Result<String, String> {
    obj.get(field)
        .and_then(Value::as_str)
        .map(str::to_owned)
        .ok_or_else(|| format!("Feld {field} fehlt"))
}

pub fn keys_of(v: &Value) -> Vec<&String> {
    v.as_object().map(|m| m.keys().collect()).unwrap_or_default()
}
