//! Wegwerf-Probe für P2 (siehe development/roadmap.md). Gibt keine Geheimnisse aus.
//!
//! Aufruf: `cargo run --release -- <befehl> [--no-browser]`
//!   login                 – P2-02: Fork-Login, Kontrollaufruf, Logout
//!   session               – P2-03: Refresh, alte Tokens, Fehlercodes, Logout
//!   drive-read [Datei]    – P2-04: Root-Ordner listen, optional Datei entschlüsseln
//!   drive-write           – P2-05: Ordner/Datei anlegen, Duplikat, Events, Löschen, Latenzen
//! Jeder Lauf meldet sich per Browser an und am Ende immer ab (keine Tokens auf Platte).

mod api;
mod drive;
mod fork;
mod session;
mod write;

use reqwest::Method;

use api::Api;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let open_browser = !args.iter().any(|a| a == "--no-browser");
    let positional: Vec<&str> =
        args.iter().filter(|a| !a.starts_with("--")).map(String::as_str).collect();
    let command = positional.first().copied().unwrap_or("login");
    let argument = positional.get(1).copied();

    println!("==============================================================");
    println!(" This is a third-party application not officially supported by Proton.");
    println!(" (Wegwerf-Probe, x-pm-appversion = {})", api::APP_VERSION);
    println!("==============================================================");

    let mut api = Api::new();
    let result = match command {
        "login" => cmd_login(&mut api, open_browser),
        "session" => fork::login(&mut api, open_browser).and_then(|_| session::run(&mut api)),
        "drive-read" => {
            fork::login(&mut api, open_browser).and_then(|kp| drive::cmd_read(&api, &kp, argument))
        }
        "drive-write" => {
            fork::login(&mut api, open_browser).and_then(|kp| write::cmd_write(&api, &kp))
        }
        other => Err(format!("unbekannter Befehl: {other}")),
    };

    // Immer abmelden, damit keine Session offen bleibt.
    if api.session.is_some() {
        logout(&mut api);
    }
    session::after_logout(&api);
    match result {
        Ok(()) => println!("\nERGEBNIS: OK"),
        Err(e) => {
            println!("\nERGEBNIS: FEHLER – {e}");
            std::process::exit(1);
        }
    }
}

fn cmd_login(api: &mut Api, open_browser: bool) -> Result<(), String> {
    let _key_password = fork::login(api, open_browser)?;
    println!("\n[check] authentifizierter Kontrollaufruf");
    let users = api.get("/core/v4/users");
    if !users.ok() {
        return Err("Kontrollaufruf /core/v4/users fehlgeschlagen".into());
    }
    let user = users.body.get("User");
    let user_fields: Vec<&String> =
        user.and_then(|u| u.as_object()).map(|m| m.keys().collect()).unwrap_or_default();
    let key_count = user.and_then(|u| u.get("Keys")).and_then(|k| k.as_array()).map_or(0, Vec::len);
    println!("  User-Felder: {user_fields:?}");
    println!("  User-Keys: {key_count}");
    println!("\nLogin OK");
    Ok(())
}

fn logout(api: &mut Api) {
    println!("\n[logout] Session widerrufen");
    let r = api.call(Method::DELETE, "/auth/v4", None, &[]);
    println!("  Logout {}", if r.ok() { "OK" } else { "FEHLGESCHLAGEN – Sitzung im Konto manuell beenden!" });
    println!("[logout] Gegenprobe: alter Token muss abgelehnt werden");
    let check = api.get("/core/v4/users");
    println!(
        "  {}",
        if check.status.as_u16() == 401 { "abgelehnt (401) – gut" } else { "NICHT abgelehnt – prüfen!" }
    );
    api.session = None;
}
