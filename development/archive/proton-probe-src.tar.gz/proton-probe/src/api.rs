//! Minimaler HTTP-Client für die Probe. Loggt pro Aufruf nur Methode, Pfad, Status,
//! Proton-`Code`, Fehlermeldung und Latenz – niemals Tokens oder Bodies.

use std::time::{Duration, Instant};

use reqwest::{blocking::Client, Method, StatusCode};
use serde_json::Value;

pub const BASE_URL: &str = "https://drive-api.proton.me";
/// Ehrliche Kennung laut SDK-README: `external-drive-{name}@{semver}-{channel}`.
pub const APP_VERSION: &str = "external-drive-tasksprobe@0.0.1-alpha";

/// Session-Daten. Absichtlich ohne `Debug`, damit sie nie versehentlich ausgegeben werden.
pub struct Session {
    pub uid: String,
    pub access_token: String,
    pub refresh_token: String,
}

pub struct Response {
    pub status: StatusCode,
    pub code: Option<i64>,
    pub body: Value,
    pub elapsed: Duration,
}

impl Response {
    pub fn ok(&self) -> bool {
        self.status.is_success() && self.code.is_none_or(|c| c == 1000 || c == 1001)
    }

    /// Feldnamen der obersten Ebene (ohne Werte) – für die Doku.
    pub fn field_names(&self) -> Vec<String> {
        match &self.body {
            Value::Object(map) => map.keys().cloned().collect(),
            _ => Vec::new(),
        }
    }
}

pub struct Api {
    pub http: Client,
    pub session: Option<Session>,
}

impl Api {
    pub fn new() -> Self {
        let http = Client::builder()
            .timeout(Duration::from_secs(30))
            .user_agent(format!("tasksprobe/{} (third-party, unofficial)", env!("CARGO_PKG_VERSION")))
            .build()
            .expect("HTTP-Client");
        Self { http, session: None }
    }

    pub fn get(&self, path: &str) -> Response {
        self.call(Method::GET, path, None, &[])
    }

    pub fn call(
        &self,
        method: Method,
        path: &str,
        json: Option<&Value>,
        extra_headers: &[(&str, &str)],
    ) -> Response {
        self.call_with(method, path, json, extra_headers, Some(APP_VERSION), true)
    }

    /// Wie [`Api::call`], aber App-Version und Session-Header steuerbar (für Fehlerfall-Proben).
    pub fn call_with(
        &self,
        method: Method,
        path: &str,
        json: Option<&Value>,
        extra_headers: &[(&str, &str)],
        app_version: Option<&str>,
        with_session: bool,
    ) -> Response {
        let mut req = self
            .http
            .request(method.clone(), format!("{BASE_URL}{path}"))
            .header("Accept", "application/vnd.protonmail.v1+json");
        if let Some(v) = app_version {
            req = req.header("x-pm-appversion", v);
        }
        if let Some(s) = self.session.as_ref().filter(|_| with_session) {
            req = req
                .header("x-pm-uid", &s.uid)
                .header("Authorization", format!("Bearer {}", s.access_token));
        }
        for (k, v) in extra_headers {
            req = req.header(*k, *v);
        }
        if let Some(body) = json {
            req = req.json(body);
        }
        self.send(method, path, req)
    }

    pub fn send(
        &self,
        method: Method,
        path: &str,
        req: reqwest::blocking::RequestBuilder,
    ) -> Response {
        let started = Instant::now();
        let result = req.send();
        let elapsed = started.elapsed();
        let resp = match result {
            Ok(r) => {
                let status = r.status();
                let retry_after = r
                    .headers()
                    .get("retry-after")
                    .and_then(|v| v.to_str().ok())
                    .map(str::to_owned);
                let body: Value = r.json().unwrap_or(Value::Null);
                let code = body.get("Code").and_then(Value::as_i64);
                let resp = Response { status, code, body, elapsed };
                log(&method, path, &resp, retry_after.as_deref());
                resp
            }
            Err(e) => {
                println!("  → {method} {path}  NETZWERKFEHLER: {e}");
                Response {
                    status: StatusCode::SERVICE_UNAVAILABLE,
                    code: None,
                    body: Value::Null,
                    elapsed,
                }
            }
        };
        resp
    }
}

fn log(method: &Method, path: &str, resp: &Response, retry_after: Option<&str>) {
    let code = resp.code.map_or_else(|| "-".to_owned(), |c| c.to_string());
    let mut line = format!(
        "  → {method:<6} {path}  HTTP {}  Code={code}  {} ms",
        resp.status.as_u16(),
        resp.elapsed.as_millis()
    );
    if let Some(err) = resp.body.get("Error").and_then(Value::as_str) {
        line.push_str(&format!("  Error=\"{err}\""));
    }
    if let Some(ra) = retry_after {
        line.push_str(&format!("  Retry-After={ra}"));
    }
    println!("{line}");
}

/// Lädt einen verschlüsselten Block von einer Storage-URL. Loggt nur Größe, Status und Latenz.
pub fn download_block(api: &Api, bare_url: &str, token: &str) -> Result<Vec<u8>, String> {
    let started = Instant::now();
    let r = api
        .http
        .get(bare_url)
        .header("pm-storage-token", token)
        .header("x-pm-appversion", APP_VERSION)
        .send()
        .map_err(|e| format!("Block-Download: {e}"))?;
    let status = r.status();
    let bytes = r.bytes().map_err(|e| format!("Block-Body: {e}"))?;
    println!(
        "  → GET    <storage-url>  HTTP {}  {} Bytes  {} ms",
        status.as_u16(),
        bytes.len(),
        started.elapsed().as_millis()
    );
    if !status.is_success() {
        return Err(format!("Block-Download HTTP {status}"));
    }
    Ok(bytes.to_vec())
}
