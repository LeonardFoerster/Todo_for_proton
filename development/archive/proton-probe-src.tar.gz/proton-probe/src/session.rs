//! P2-03: Token-Refresh, Verhalten alter Tokens, Logout und Fehlercodes beobachten.
//! Rate-Limits und Human Verification werden bewusst NICHT provoziert (Proton-Regeln).

use reqwest::Method;
use serde_json::{json, Value};

use crate::api::{Api, Session};

pub fn run(api: &mut Api) -> Result<(), String> {
    println!("\n[p2-03] Kontrollaufruf mit frischer Session");
    if !api.get("/core/v4/users").ok() {
        return Err("Kontrollaufruf fehlgeschlagen".into());
    }

    println!("\n[p2-03] Fehlercodes (harmlose, absichtlich fehlerhafte Anfragen)");
    println!("  a) ohne x-pm-appversion:");
    api.call_with(Method::GET, "/core/v4/users", None, &[], None, true);
    println!("  b) mit ungültigem x-pm-appversion:");
    api.call_with(Method::GET, "/core/v4/users", None, &[], Some("not-a-valid-version"), true);
    println!("  c) mit ungültigem Access-Token:");
    let uid = api.session.as_ref().map(|s| s.uid.clone()).unwrap_or_default();
    api.call_with(
        Method::GET,
        "/core/v4/users",
        None,
        &[("x-pm-uid", &uid), ("Authorization", "Bearer invalid-token")],
        Some(crate::api::APP_VERSION),
        false,
    );
    println!("  d) ohne Session:");
    api.call_with(Method::GET, "/core/v4/users", None, &[], Some(crate::api::APP_VERSION), false);

    println!("\n[p2-03] Token-Refresh");
    let old_access = api.session.as_ref().map(|s| s.access_token.clone()).unwrap_or_default();
    let old_refresh = refresh(api)?;

    println!("\n[p2-03] neuer Access-Token:");
    let new_ok = api.get("/core/v4/users").ok();
    println!("  {}", if new_ok { "gültig" } else { "UNGÜLTIG" });

    println!("[p2-03] alter Access-Token nach Refresh:");
    let old = api.call_with(
        Method::GET,
        "/core/v4/users",
        None,
        &[("x-pm-uid", &uid), ("Authorization", &format!("Bearer {old_access}"))],
        Some(crate::api::APP_VERSION),
        false,
    );
    println!("  {}", if old.ok() { "noch gültig" } else { "abgelehnt" });

    // Alten Refresh-Token NICHT vor dem Logout wiederverwenden: Token-Reuse-Erkennung könnte
    // die Session widerrufen und den Logout-Test verfälschen. Das passiert in `after_logout`.
    STASH.with(|s| *s.borrow_mut() = Some((uid, old_refresh)));
    Ok(())
}

/// Nach dem Logout: Refresh mit dem (inzwischen ungültigen) Refresh-Token versuchen.
pub fn after_logout(api: &Api) {
    let Some((uid, refresh_token)) = STASH.with(|s| s.borrow_mut().take()) else {
        return;
    };
    println!("\n[p2-03] Refresh mit altem Refresh-Token nach Logout:");
    let r = api.call_with(
        Method::POST,
        "/auth/v4/refresh",
        Some(&refresh_body(&refresh_token)),
        &[("x-pm-uid", &uid)],
        Some(crate::api::APP_VERSION),
        false,
    );
    println!("  {}", if r.ok() { "UNERWARTET erfolgreich – Session prüfen!" } else { "abgelehnt – gut" });
}

thread_local! {
    static STASH: std::cell::RefCell<Option<(String, String)>> = const { std::cell::RefCell::new(None) };
}

/// Führt einen Refresh aus, übernimmt die neuen Tokens und liefert den alten Refresh-Token.
fn refresh(api: &mut Api) -> Result<String, String> {
    let (uid, refresh_token) = {
        let s = api.session.as_ref().ok_or("keine Session")?;
        (s.uid.clone(), s.refresh_token.clone())
    };
    if refresh_token.is_empty() {
        return Err("Fork lieferte keinen Refresh-Token".into());
    }
    let r = api.call_with(
        Method::POST,
        "/auth/v4/refresh",
        Some(&refresh_body(&refresh_token)),
        &[("x-pm-uid", &uid)],
        Some(crate::api::APP_VERSION),
        false,
    );
    if !r.ok() {
        return Err("Refresh fehlgeschlagen".into());
    }
    println!("  Felder: {:?}", r.field_names());
    let field = |name: &str| r.body.get(name).and_then(Value::as_str).map(str::to_owned);
    let rotated = field("RefreshToken").is_some_and(|t| t != refresh_token);
    println!("  Refresh-Token rotiert: {rotated}");
    println!("  UID unverändert: {}", field("UID").is_none_or(|u| u == uid));
    api.session = Some(Session {
        uid: field("UID").unwrap_or(uid),
        access_token: field("AccessToken").ok_or("AccessToken fehlt")?,
        refresh_token: field("RefreshToken").unwrap_or_else(|| refresh_token.clone()),
    });
    Ok(refresh_token)
}

fn refresh_body(refresh_token: &str) -> Value {
    json!({
        "ResponseType": "token",
        "GrantType": "refresh_token",
        "RefreshToken": refresh_token,
        "RedirectURI": "https://proton.me",
    })
}
